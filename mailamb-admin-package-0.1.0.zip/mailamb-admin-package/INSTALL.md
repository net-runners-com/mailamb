# mailamb 管理者用拡張 インストール手順

対象: 管理者 1〜数名の PC (Mac / Windows / Linux)
所要時間: 10分

## 事前準備

管理者から受け取っておく:
- `mailamb-admin-0.1.0.xpi` (拡張本体)
- **Worker URL** (`https://mailamb.<サブドメイン>.workers.dev`)
- **API Key** (64文字)

## STEP 1: TB プロファイル場所確認

TBメニュー → ヘルプ → **トラブルシューティング情報** → 「プロファイルフォルダー」の **フォルダーを開く** クリック。

例:
- macOS: `/Users/<name>/Library/Thunderbird/Profiles/xxxxxx.default-release/`
- Windows: `C:\Users\<name>\AppData\Roaming\Thunderbird\Profiles\xxxxxx.default-release\`
- Linux: `~/.thunderbird/xxxxxx.default-release/`

## STEP 2: user.js に未署名許可を追加

プロファイルフォルダ内の `user.js` に以下を**1行追加** (既にあればスキップ):

```
user_pref("xpinstall.signatures.required", false);
```

**スタッフ用拡張も入れる場合はこの設定が既にあるはず**。

## STEP 3: 拡張ファイル配置

プロファイル配下の `extensions/` フォルダ (無ければ作成) に `.xpi` を配置し、ファイル名を:

```
mailamb-admin@mailamb.local.xpi
```

に rename。

**ファイル名重要**。別名だと認識されない。

## STEP 4: TB 完全再起動

Thunderbird を終了 (Cmd+Q / Alt+F4) → もう一度起動。

## STEP 5: 拡張有効化確認

TB → ツール → アドオンとテーマ → `mailamb — 管理者ダッシュボード` が **有効 (青トグル)** になっているか確認。

無効なら有効化 → 再起動。

## STEP 6: 設定入力

アドオンマネージャで `mailamb — 管理者ダッシュボード` の **歯車 → オプション**。

| 項目 | 入力内容 |
|---|---|
| **Worker URL** | 管理者から受け取ったURL |
| **API Key** | 管理者から受け取ったキー |

保存。

## STEP 7: ダッシュボード起動

TB のツールバーに **mailamb 管理** ボタンが追加されている (アイコンクリック可能)。

→ クリック → **TB 内に新しいタブで管理ダッシュボードが開く**。

無ければ: ツールバーで右クリック → ツールバーをカスタマイズ → `mailamb 管理` をドラッグして追加。

## STEP 8: 動作確認

ダッシュボード右上の接続ステータスが **緑 (接続OK)** になっているか確認。

→ ナレッジタブに切り替えて、Workerに登録済みのナレッジ一覧が表示されるか確認。

## よくあるトラブル

### 「mailamb 管理」ボタンが出ない
- 拡張が無効 → アドオンマネージャで有効化
- ツールバーに追加されていない → ツールバーをカスタマイズで追加

### 接続NG
- Worker URL / API Key を再確認 (余計な空白が入ってないか)
- Worker 側の `/health` が返るか: `curl https://<worker>/health`

### ダッシュボードが空白
- 設定を保存していない → 歯車 → オプションから保存
- Worker 側にナレッジが未投入 → 「追加」タブから登録

### 開発者ツールでデバッグ
TBの「ツール → 開発者ツール → ブラウザコンソール」で `[mailamb-admin]` ログが出る。

## アンインストール手順

1. アドオンマネージャで `mailamb — 管理者ダッシュボード` の `...` → 削除
2. もしくは `extensions/mailamb-admin@mailamb.local.xpi` ファイルを削除
3. TB 再起動

削除してもスタッフ用拡張や既存メールには影響なし。
